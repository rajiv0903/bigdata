ADD JAR /mnt/home/edureka_390782/hiveudf.jar;

CREATE DATABASE healthDB9sep;
USE healthDB9sep;

CREATE TABLE healthCareSampleDS (PatientID INT, Name STRING, DOB STRING, PhoneNumber STRING, EmailAddress STRING, SSN STRING, Gender STRING, Disease STRING, weight FLOAT) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',';

LOAD DATA LOCAL INPATH '/mnt/home/edureka_390782/healthcare_Sample_dataset1.csv' INTO table healthCareSampleDS;

CREATE TEMPORARY FUNCTION deIdentify AS 'Deidentify';

CREATE TABLE healthCareSampleDSDeidentified AS SELECT PatientID, deIdentify(Name), deIdentify(DOB), deIdentify(PhoneNumber), deIdentify(EmailAddress), deIdentify(SSN), deIdentify(Gender), deIdentify(Disease), deIdentify(weight) FROM healthCareSampleDS;
